// Shared shell for surveillance pages — sidebar + topbar that link across pages

const NVRSidebar = ({ active }) => (
  <aside className="sidebar">
    <div className="brand">
      <div className="brand-mark">Z·M</div>
      <div>
        <div className="brand-name">Zabbix · TCS</div>
        <div className="brand-sub">+ Milestone XProtect</div>
      </div>
    </div>

    <div className="nav-section">
      <div className="nav-label">Monitoring</div>
      <a className="nav-item" href="Zabbix Dashboard.html"><Icon name="map" /> Dashboards</a>
      <a className="nav-item" href="Zabbix Dashboard.html"><Icon name="ap" /> Hosts <span className="nav-count">2,418</span></a>
      <a className="nav-item" href="Zabbix Dashboard.html"><Icon name="wifi" /> Wireless APs <span className="nav-count">1,184</span></a>
      <a className="nav-item"><Icon name="ethernet" /> Switches <span className="nav-count">312</span></a>
      <a className="nav-item"><Icon name="alert" /> Problems <span className="nav-count warn">23</span></a>
      <a className="nav-item"><Icon name="events" /> Events</a>
    </div>

    <div className="nav-section">
      <div className="nav-label">Surveillance (Milestone)</div>
      <a className={"nav-item" + (active === "overview" ? " active" : "")} href="Surveillance Dashboard.html"><Icon name="map" /> NOC Overview</a>
      <a className={"nav-item" + (active === "cameras"  ? " active" : "")} href="Camera Detail.html"><Icon name="ap" /> Cameras <span className="nav-count">1,147</span></a>
      <a className={"nav-item" + (active === "servers"  ? " active" : "")} href="Server Detail.html"><Icon name="ethernet" /> Recording Servers <span className="nav-count">8</span></a>
      <a className="nav-item"><Icon name="shield" /> Evidence Lock <span className="nav-count">7</span></a>
      <a className="nav-item"><Icon name="alert" /> VMS Alarms <span className="nav-count warn">12</span></a>
    </div>

    <div className="nav-section">
      <div className="nav-label">Sites</div>
      <a className="nav-item">Bryant High School</a>
      <a className="nav-item muted">Central High School</a>
      <a className="nav-item muted">Northridge High School</a>
      <a className="nav-item muted">+ 23 more sites</a>
    </div>

    <div className="sidebar-footer">
      <div className="row"><span>Zabbix Server</span><span className="ok">● 7.0.4</span></div>
      <div className="row"><span>XProtect Mgmt</span><span className="ok">● 24.2 R2</span></div>
      <div className="row"><span>Recording Srvs</span><span className="ok">● 6 / 6</span></div>
    </div>
  </aside>
);

const NVRTopbar = ({ crumb }) => (
  <div className="topbar">
    <div className="icon-btn"><Icon name="back" /></div>
    <div className="crumb">
      {crumb.map((c, i) => (
        <React.Fragment key={i}>
          {i > 0 && <span className="sep">/</span>}
          <span className={i === crumb.length - 1 ? "seg" : ""}>{c}</span>
        </React.Fragment>
      ))}
    </div>
    <div className="spacer" />
    <div className="search">
      <Icon name="search" />
      <input placeholder="Find camera, server, MAC, IP…" readOnly />
      <kbd>⌘K</kbd>
    </div>
    <div className="icon-btn"><Icon name="refresh" /></div>
    <div className="icon-btn"><Icon name="more" /></div>
  </div>
);

window.NVRSidebar = NVRSidebar;
window.NVRTopbar = NVRTopbar;
